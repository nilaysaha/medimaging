$ sudo apt-get install maven
$ mvn test
