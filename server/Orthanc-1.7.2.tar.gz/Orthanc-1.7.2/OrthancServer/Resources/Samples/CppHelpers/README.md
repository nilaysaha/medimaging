This folder contains a bunch of helpers that are used in multiple Orthanc side projects (either plugins, standalone executables using the Orthanc framework or orthanc-stone based applications)

When writing plugins, you may also want to check the Plugins/Samples/Common folder for other helpers.